import tkinter as tk
import numpy as np

class DynamicChart:
    def __init__(self, initial_data, canvas):
        self.canvas = canvas
        self.values = initial_data
        self.t = 0
        self.init_chart()
        
    def init_chart(self):
        self.canvas.delete("all")
        self.canvas.config(width=500, height=250)
        self.draw_line()

    def add_value(self, new_value):
        self.values.pop(0)
        self.values.append(new_value)
        self.draw_line()

    def draw_line(self):
        self.canvas.delete("line")
        num_values = len(self.values)
        
        x_start = 40
        y_start = 220
        x_step = 410 / (num_values - 1)
        y_scale = 4
        
        smoothed_values = self.smooth_data(self.values)  # Smoothing the data
        
        for i in range(num_values - 1):
            x1 = x_start + i * x_step
            x2 = x_start + (i + 1) * x_step
            y1 = y_start - smoothed_values[i] * y_scale
            y2 = y_start - smoothed_values[i + 1] * y_scale
            self.canvas.create_line(x1, y1, x2, y2, fill="red", width=2, tags="line")

    def smooth_data(self, data, window_size=5):
        smoothed_data = np.convolve(data, np.ones(window_size) / window_size, mode='valid')
        return np.concatenate(([data[0]] * (len(data) - len(smoothed_data)), smoothed_data))

if __name__ == "__main__":
    root = tk.Tk()
    canvas = tk.Canvas(root)
    canvas.pack()

    initial_data = [0] * 20
    group_1_dynamic_chart = DynamicChart(initial_data, canvas)

    def update_chart():
        new_value = np.random.randint(0, 60)
        group_1_dynamic_chart.add_value(new_value)
        root.after(500, update_chart)

    update_chart()
    root.mainloop()
