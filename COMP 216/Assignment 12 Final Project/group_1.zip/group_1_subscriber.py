import tkinter as tk
from tkinter import ttk
import paho.mqtt.client as mqtt
from group_1_dynamic_chart import DynamicChart
import json
import threading

# Global variables
MQTT_BROKER = 'localhost'
DEFAULT_MQTT_TOPIC = 'Temperature Over Time'

class TemperatureSubscriberGUI:
    def __init__(self, root):
        self.root = root
        self.root.title('Subscriber')
        self.inDisconnect = False
        self.next_packet_id = 0
        self.is_publishing = False
        
        # Set weight to make columns and rows resizable
        for i in range(6):
            self.root.rowconfigure(i, weight=1)
        
        # add a valid data range min and max values entry boxes
        self.valid_min_var = tk.StringVar(value=0)
        self.valid_min_label = ttk.Label(root, text='Valid Min Value:')
        self.valid_min_entry = ttk.Entry(root, textvariable=self.valid_min_var)
        self.valid_min_label.grid(row=1, column=0, padx=10, sticky='ew')
        self.valid_min_entry.grid(row=1, column=1, padx=10, sticky='ew')
        
        self.valid_max_var = tk.StringVar(value=45)
        self.valid_max_label = ttk.Label(root, text='Valid Max Value:')
        self.valid_max_entry = ttk.Entry(root, textvariable=self.valid_max_var)
        self.valid_max_label.grid(row=2, column=0, padx=10, sticky='ew')
        self.valid_max_entry.grid(row=2, column=1, padx=10, sticky='ew')
        
        self.text_label = ttk.Label(root, text='Recieved Temperature Values:')
        self.text_label.grid(row=3, column=0, columnspan=2, padx=10, pady=10, sticky='ns')
        
        self.text_display = tk.Text(root, wrap='word', width=40, height=10)
        self.text_display.grid(row=4, column=0, columnspan=2, padx=10, pady=10, sticky='nsew')
        
        scrollbar = tk.Scrollbar(root, command=self.text_display.yview)
        scrollbar.grid(row=4, column=3, sticky='nsew')
        self.text_display.config(yscrollcommand=scrollbar.set)
        
        # add connect and disconnect buttons
        self.connect_button = ttk.Button(root, text='Connect', command=self.connect_to_broker)
        self.disconnect_button = ttk.Button(root, text='Disconnect', command=self.disconnect_from_broker)
        self.connect_button.grid(row=0, column=0, padx=10, pady=10)
        self.disconnect_button.grid(row=0, column=1, padx=10, pady=10)
        
        self.connect_button['state'] = 'enabled'
        self.disconnect_button['state'] = 'disabled'
        
        # add start and stop buttons
        self.start_button = ttk.Button(root, text='Start publishing', command=self.start_publishing)
        self.stop_button = ttk.Button(root, text='Stop publishing', command=self.stop_publishing)
        self.start_button.grid(row=5, column=0, padx=10, pady=10)
        self.stop_button.grid(row=5, column=1, padx=10, pady=10)
        
        self.stop_button['state'] = 'disabled'
        
        # entry value for topic
        self.topic_var = tk.StringVar(value=DEFAULT_MQTT_TOPIC)
        self.topic_label = ttk.Label(root, text='Topic:')
        self.topic_entry = ttk.Entry(root, textvariable=self.topic_var)
        self.topic_label.grid(row=6, column=0, padx=10, pady=10, sticky='e')
        self.topic_entry.grid(row=6, column=1, padx=10, pady=10, sticky='w')
        
        # MQTT client setup
        self.mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION1)
        self.mqtt_client.on_message = self.on_message
        self.mqtt_client.on_connect = self.on_connect
        self.mqtt_client.on_disconnect = self.on_disconnect
        
        # Create a canvas widget
        self.chart_canvas = tk.Canvas(root)
        self.chart_canvas.grid(row=0, column=5, rowspan=6, padx=10, pady=10, sticky='ew')

        # Pass the canvas widget to DynamicChart
        initial_data = [0] * 20
        self.dynamic_chart = DynamicChart(initial_data, self.chart_canvas)
        
        
    def connect_to_broker(self):
        self.mqtt_client.connect(MQTT_BROKER, 1883, 60)
        try:
            self.mqtt_client.loop_start()
            print('Started loop')
        except Exception as e:
            print('Unable to start loop')
            print(e)
        # update button states
        self.connect_button['state'] = 'disabled'
        self.disconnect_button['state'] = 'normal'
        
    def disconnect_from_broker(self):
        self.inDisconnect = True
        self.mqtt_client.loop_stop()
        self.mqtt_client.disconnect()
        # update button states
        self.connect_button['state'] = 'normal'
        self.disconnect_button['state'] = 'disabled'
        
    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            #self.dynamic_chart.set_title(self.topic_var.get())
            print(f'Connected to "{MQTT_BROKER}"')
            self.mqtt_client.subscribe(self.topic_var.get())
            self.connect_button['state'] = 'disabled'
            self.disconnect_button['state'] = 'normal'
            # enable start button
            self.start_button['state'] = 'normal'
        else:
            print(f'Connection failed, with result code:  {rc}')
            
    def on_disconnect(self, client, userdata, rc):
        if rc != 0:
            print(f'Unexpected disconnection. Result code: {rc}')
        else:
            print(f'Disconnected')
            
        self.connect_button['state'] = 'normal'
        self.disconnect_button['state'] = 'disabled'
        self.topic_entry['state'] = 'normal'
        
    def start_publishing(self):
        if not self.is_publishing:
            self.is_publishing = True
            self.temperature_thread = threading.Thread(target=self.publish_temperature)
            self.temperature_thread.start()
            self.stop_button['state'] = 'normal'
            self.start_button['state'] = 'disabled'
            self.topic_entry['state'] = 'disabled'
            
    def stop_publishing(self):
        if self.is_publishing:
            self.is_publishing = False
            self.temperature_thread.join()
            self.stop_button['state'] = 'disabled'
            self.start_button['state'] = 'normal'
            self.topic_entry['state'] = 'normal'
            
    def publish_temperature(self):
        while self.is_publishing:
            self.packet_id_counter += 1
            
            # generate the data with packet and timestamp
            temperature_value = self.data_generator.value
            
            if self.skip_next_count > 0:
                self.skip_next_count -= 1
                print(f'Skipping packet {self.packet_id_counter}')
                continue
            
        
    # gets triggered whenever a message is received from the MQTT broker
    def on_message(self, client, userdata, msg):
        if self.inDisconnect:
            return
        
        # Decode the message and load it as json
        json_data = json.loads(msg.payload.decode('utf-8'))
        # Extract the temperature
        temperature_value = json_data['temperature']
        # Extract the timestamp 
        timestamp = json_data['timestamp']
        # Extract the packet ID
        packet_id = json_data['packet_id']
        
        # if the received packet ID is different from the expected next packet ID
        if (self.next_packet_id > 0 and packet_id != self.next_packet_id):
            print(f"Warning: received packet {packet_id} out of order")
            self.text_display.insert(tk.END, f'Packet {self.next_packet_id}')
            
        # Updates the expected next packet ID
        self.next_packet_id = packet_id + 1
        
        # try catch
        try:
            if (temperature_value < float(self.valid_min_var.get()) or temperature_value > float(self.valid_max_var.get())):
                print(f"Error: Value out of range, packet: {packet_id} received out of order")
                self.text_display.insert(tk.END, f'Packet: {packet_id} out of range')
                self.text_display.see(tk.END)
                return
        except ValueError:
            print(f'Invalid imput value')
            
        print(f"Received packet {packet_id} at {timestamp}: {self.topic_var.get()}")
        self.text_display.insert(tk.END, f'Packet {packet_id}: {temperature_value}')
        self.text_display.see(tk.END)
        
        # update chart
        self.dynamic_chart.add_value(temperature_value)
        
if __name__ == '__main__':
    root = tk.Tk()
    app = TemperatureSubscriberGUI(root)
    
    def on_closing():
        app.mqtt_client.disconnect()
        root.destroy()
        
    root.protocol("WM_DELETE_WINDOW", on_closing)
    root.mainloop()