import math
import random

#1. Class
class DataGenerator:
    
    def __init__(self, ymin=18, ymax=25, daily_mean=19, daily_amps=[2, 1.5, 2, 1.8, 2.2], stddev=0.5, readings_per_day=100):
        self.ymin = ymin
        self.ymax = ymax
        self.readings_per_day = readings_per_day

        # Parameters for daily sine fluctuations
        self.daily_mean = daily_mean
        self.daily_amps = daily_amps
        self.set_daily_freqs()

        self.stddev = stddev

        self.t = 0
    
    @property
    def readings_per_day(self):
        return self._readings_per_day
    
    # setter for readings per day
    @readings_per_day.setter
    def readings_per_day(self, value):
        if value <= 0:
            raise ValueError('readings per day must be greater than 0')
        self._readings_per_day = value
        self.set_daily_freqs()
        
    def set_daily_freqs(self):
        self.daily_freqs = [2 * math.pi / self._readings_per_day, 0.5 * math.pi / self._readings_per_day, 
                            1.8 * math.pi / self._readings_per_day, 0.8 * math.pi / self._readings_per_day, 
                            1.1 * math.pi / self._readings_per_day]  # 100 temperature readings per day

    #2. private method
    def __rand_values(self):
        return random.uniform(0,1)
    
    def _normal_random(self):
        return random.gauss(0, self.stddev)
    
    @property
    def value(self):
        # Daily sin fluctuation
        daily_pattern = self.daily_mean
        
        # Other fluctuations
        for i in range(len(self.daily_amps)):
            daily_pattern += self.daily_amps[i] * math.sin(self.daily_freqs[i] * self.t)
            
        # noise
        noise = self._normal_random()
        
        y = daily_pattern + noise
        
        # scale y to be in the range of 0 - 1
        y = y / (sum(self.daily_amps) + self.daily_mean)
        
        # scale y to be in the range ymin - ymax
        yrange = self.ymax - self.ymin
        y = self.ymin + yrange * y
        
        # increase time
        self.t += 1
        
        return y
