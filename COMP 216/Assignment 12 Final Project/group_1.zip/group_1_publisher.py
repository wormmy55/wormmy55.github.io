import tkinter as tk
from tkinter import ttk
import random
import threading
import time
import json
import paho.mqtt.client as mqtt
import group_1_data_generator as dg

# Global variables for initial values
DEFAULT_MIN_VALUE = '0'
DEFAULT_MAX_VALUE = '45'
DEFAULT_DAILY_MEAN = '20'
DEFAULT_READINGS_PER_DAY = '48'
MQTT_BROKER = 'localhost'
DEFAULT_MQTT_TOPIC = 'Temperature Over Time'
TRANSMISSION_ERROR_RATE = 0.01

class TemperaturePublisherGui:
    def __init__(self, root):
        self.root = root
        self.root.title('Publisher')
        self.is_publishing = False  # Initialize the publishing flag
        
        # Set weight to make columns and rows resizable
        for i in range(6):
            self.root.rowconfigure(i, weight=1)
        
        # Default values for the entry widgets
        self.min_value_var = tk.DoubleVar(value=DEFAULT_MIN_VALUE)
        self.max_value_var = tk.DoubleVar(value=DEFAULT_MAX_VALUE)
        self.daily_mean_var = tk.DoubleVar(value=DEFAULT_DAILY_MEAN)
        self.readings_per_day_var = tk.DoubleVar(value=DEFAULT_READINGS_PER_DAY)
        
        self.topic_var = tk.StringVar(value=DEFAULT_MQTT_TOPIC)
        
        # add labels and entries
        self.min_label = ttk.Label(root, text='Min Value:')
        self.min_entry = ttk.Entry(root, textvariable=self.min_value_var)
        self.min_label.grid(row=1, column=0, padx=10, sticky='e')
        self.min_entry.grid(row=1, column=1, padx=10, sticky='w')
        
        self.max_label = ttk.Label(root, text='Max Value:')
        self.max_entry = ttk.Entry(root, textvariable=self.max_value_var)
        self.max_label.grid(row=2, column=0, padx=10, sticky='e')
        self.max_entry.grid(row=2, column=1, padx=10, sticky='w')
        
        self.daily_mean_label = ttk.Label(root, text='Daily Mean:')
        self.daily_mean_entry = ttk.Entry(root, textvariable=self.daily_mean_var)
        self.daily_mean_label.grid(row=3, column=0, padx=10, sticky='e')
        self.daily_mean_entry.grid(row=3, column=1, padx=10, sticky='w')
        
        self.readings_per_day_label = ttk.Label(root, text='Readings Per Day:')
        self.readings_per_day_entry = ttk.Entry(root, textvariable=self.readings_per_day_var)
        self.readings_per_day_label.grid(row=4, column=0, padx=10, sticky='e')
        self.readings_per_day_entry.grid(row=4, column=1, padx=10, sticky='w')
        
        # update button
        self.update_button = ttk.Button(root, text="Update", command=self.update_values)
        self.update_button.grid(row=5, column=0, columnspan=2, pady=10)
        self.update_button['state'] = 'disabled'
        
        # add start and stop buttons
        self.start_button = ttk.Button(root, text='Start publishing', command=self.start_publishing)
        self.stop_button = ttk.Button(root, text='Stop publishing', command=self.stop_publishing)
        self.start_button.grid(row=6, column=0, padx=10, pady=10)
        self.stop_button.grid(row=6, column=1, padx=10, pady=10)
        
        # entry value for Topic
        self.topic_label = ttk.Label(root, text='Topic:')
        self.topic_entry = ttk.Entry(root, textvariable=self.topic_var)
        self.topic_label.grid(row=7, column=0, padx=10, pady=10, sticky='e')
        self.topic_entry.grid(row=7, column=1, padx=15, pady=10, sticky='w')
        
        # set start and stop buttons
        self.start_button['state'] = 'disabled'
        self.stop_button['state'] = 'disabled'
        
        # add connect and disconnect buttons
        self.connect_button = ttk.Button(root, text='Connect', command=self.connect_to_broker)
        self.disconnect_button = ttk.Button(root, text='Disconnect', command=self.disconnect_from_broker)
        self.connect_button.grid(row=0, column=0, padx=10, pady=10)
        self.disconnect_button.grid(row=0, column=1, padx=10, pady=10)
        
        # set connect and disconnect buttons
        self.connect_button['state'] = 'enabled'
        self.disconnect_button['state'] = 'disabled'
        
        # Bonus
        self.separator = ttk.Separator(root, orient='horizontal')
        self.separator.grid(row=8, column=0, columnspan=2, sticky='ew', padx=10, pady=10)
        
        # add button to transmit wild data
        self.wild_data_button = ttk.Button(root, text='Transmit Wild Data', command=self.wild_data)
        self.wild_data_button.grid(row=10, column=0, padx=10, pady=10)
        
        # add button to skip block of data
        self.skip_button = ttk.Button(root, text='Skip Block of Data', command=self.skip_blocks)
        self.skip_button.grid(row=10, column=1, padx=10, pady=10)
        
        # set the buttons
        self.wild_data_button['state'] = 'disabled'
        self.skip_button['state'] = 'disabled'
        
        # setup MQTT client
        self.mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION1)
        self.mqtt_client.on_connect = self.on_connect
        self.mqtt_client.on_disconnect = self.on_disconnect
        
        # add trace to detect value changes to the min, max, mean
        self.min_value_var.trace_add('write', self.on_value_changed)
        self.max_value_var.trace_add('write', self.on_value_changed)
        self.daily_mean_var.trace_add('write', self.on_value_changed)
        self.readings_per_day_var.trace_add('write', self.on_value_changed)
        
        self.data_generator = dg.DataGenerator(ymin=self.min_value_var.get(),
                                               ymax=self.max_value_var.get(),
                                               daily_mean=self.daily_mean_var.get(),
                                               readings_per_day=self.readings_per_day_var.get())
        
        # initialize packet counter
        self.packet_id_counter = 0
        # initialize skip next count for simulation of lost packets
        self.skip_next_count = 0
        
        # initialize flag for wild data
        self.is_wild_data = False
        
    # simulate unpredictable spikes or drops in temperature
    def wild_data(self):
        self.is_wild_data = True
        
    def skip_blocks(self):
        # number of packets to skip is chosen randomly between 1 and 10
        self.skip_next_count = random.randint(1, 10)
        
    # called when the MQTT client successfully connects to the MQTT broker
    def on_connect(self, client, userdata, flags, rc):
        # The connection result = 0
        if rc == 0:
            print(f'Connected to "{MQTT_BROKER}"')
            self.connect_button['state'] = 'disabled'
            self.disconnect_button['state'] = 'normal'
            # enable start button
            self.start_button['state'] = 'normal'
        else:
            print(f'Connection failed, with result code:  {rc}')
            
    def on_disconnect(self, client, userdata, rc):
        if rc != 0:
            print(f'Unexpected disconnection. Result code: {rc}')
        else:
            print(f'Disconnected')
            
        # set flag to stop the loop
        self.loop_active = False
        self.connect_button['state'] = 'normal'
        self.disconnect_button['state'] = 'disabled'
        
        # disabled buttons
        self.start_button['state'] = 'disabled'
        self.stop_button['state'] = 'disabled'
        self.wild_data_button['state'] = 'disabled'
        self.skip_button['state'] = 'disabled'
        
        # stop publishing
        self.stop_publishing()
        
    # establishes a connection to the MQTT broker
    def connect_to_broker(self):
        self.mqtt_client.connect(MQTT_BROKER, 1883, 60)
        self.mqtt_client.loop_start()
        
        # update button states
        self.connect_button['state'] = 'disabled'
        self.disconnect_button['state'] = 'normal'
        
    def disconnect_from_broker(self):
        self.stop_publishing()
        self.mqtt_client.loop_stop()
        
        # update button states
        self.connect_button['state'] = 'normal'
        self.disconnect_button['state'] = 'disabled'
        
    def start_publishing(self):
        if not self.is_publishing:
            self.is_publishing = True
            self.temperature_thread = threading.Thread(target=self.publish_temperature)
            self.temperature_thread.start()
            self.stop_button['state'] = 'normal'
            self.start_button['state'] = 'disabled'
            self.topic_entry['state'] = 'disabled'
            self.wild_data_button['state'] = 'normal'
            self.skip_button['state'] = 'normal'
            
    def stop_publishing(self):
        if self.is_publishing:
            self.is_publishing = False
            self.temperature_thread.join()
            self.stop_button['state'] = 'disabled'
            self.start_button['state'] = 'normal'
            self.topic_entry['state'] = 'normal'
            self.wild_data_button['state'] = 'disabled'
            self.skip_button['state'] = 'disabled'
        
    def publish_temperature(self):
        # as long as self.is_publishing is True
        while self.is_publishing:
            # increments the packet_id_counter by 1
            self.packet_id_counter += 1
            
            # generate the data with packet and timestamp
            temperature_value = self.data_generator.value
            
            if self.skip_next_count > 0:
                self.skip_next_count -= 1
                print(f'Skipping packet {self.packet_id_counter}')
                # continue to the next iteration of the loop without publishing data
                continue
            
            if self.is_wild_data:
                
                if random.random() < 0.5:
                    temperature_value += 1000000
                else:
                    temperature_value += -1000000
                self.is_wild_data = False
            
            # preparing the data
            # create a dictionary containing the temperature value, timestamp, and packet ID.
            data = {
                "temperature": temperature_value,
                "timestamp": time.strftime('%Y-%m-%d %H:%M:%S'),
                "packet_id": self.packet_id_counter
            }
            
            # convert data to json string
            json_data = json.dumps(data)
            
            # randomly skip 1% of the packets
            # randomly decides whether to skip the current packet
            if random.random() < TRANSMISSION_ERROR_RATE:
                print(f'Skipping packet {self.packet_id_counter}')
                continue
            
            # publish json data
            print(f'publishing {self.topic_var.get()}: {json_data}')
            self.mqtt_client.publish(self.topic_var.get(), payload=json_data)
            
            time.sleep(1) # pause 1 second between publishing
            
    # updates the parameters of the data_generator object based on the values entered
    def update_values(self):
        self.data_generator.ymin = self.min_value_var.get()
        self.data_generator.ymax = self.max_value_var.get()
        self.data_generator.daily_mean = self.daily_mean_var.get()
        self.data_generator.readings_per_day = self.readings_per_day_var.get()
        self.update_button['state'] = 'disabled'
        
    # called if values change
    def on_value_changed(self, *args):
        # enable the update button when a value changes
        self.update_button['state'] = 'normal'
        
        
if __name__ == '__main__':
    
    def on_closing():
        if app.is_publishing():
            app.stop_publishing()
            
        # disconnect
        app.disconnect_from_broker()
        root.destroy()
        
    root = tk.Tk()
    app = TemperaturePublisherGui(root)
    root.protocol('WM_DELETE_WINDOW', on_closing)
    
    root.mainloop()