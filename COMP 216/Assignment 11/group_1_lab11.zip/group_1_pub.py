import json
import time
import paho.mqtt.client as mqtt
from group_1_util import create_data

def publish_data():
    client = mqtt.Client()
    client.connect("test.mosquitto.org", 1883, 60)

    try:
        for _ in range(10):
            data = create_data()
            data_string = json.dumps(data)
            client.publish("student_data", data_string)
            print("Data Published:", data_string)
            time.sleep(2)

    finally:
        client.disconnect()
        print("Disconnected")