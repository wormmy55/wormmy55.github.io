import random
import time

start_id = 111

# function that will create and return a dict
def create_data(student):
  global start_id
  data = {
        'id': start_id,                                 # sequence number
        'student': student,                             # name of student
        'time': time.asctime(),                         # time this was generated
        "attendance": random.randint(0, 100),           # attendance percentage
        "study_hours_per_week": random.randint(5, 30),  # study hours per week
        "clubs": ["Academic", "Political", "Athletic"], # participation in clubs
        "test_scores": {
                "MATH210": random.randint(60, 100),     # test scores for different courses
                "COMP216": random.randint(60, 100),
                "GNED500": random.randint(60, 100)
            },
        'program': 'Softwr. Eng. Tech. - AI'
    }
  start_id += 1
  return data

# function that will take a dict and print the parts in a human-readable format
def print_data(data):
    print("ID:", data['id'])
    print("Student:", data['student'])
    print("Time:", data['time'])
    print("Study hours per week:", data['study_hours_per_week'])
    print("Clubs:", ', '.join(data['clubs']))
    print("Test scores:", data['test_scores'])
    print("Program:", data['program'])