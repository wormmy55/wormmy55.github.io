import json
import time
import paho.mqtt.client as mqtt
from group_1_util import create_data

def connect():
  #Create Client
  client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION1)

  #Connect to server
  client.connect("test.mosquitto.org", 1883, 60)

  # On_message callback
  client.on_message = decode

  #Subscribe to topic
  client.subscribe("student_data")

  #Print a message
  print("Subscriber successful.")

  #Invoke the client loop_forever() method
  client.loop_forever()

def decode(client, userdata, message):
    try:
        #Decode
        decoded = message.payload.decode("utf-8")

        #Convert decode
        convert_decode = json.loads(decoded)

        #Call function from 1st file
        call_dict = create_data(convert_decode)

    except Exception as e:
      print("Error while decoding message: ", e)

#Call the connect function
connect()